package com.semana3.citasmedicas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CitasmedicasApplicationTests {

	@Test
	void contextLoads() {
	}

}
